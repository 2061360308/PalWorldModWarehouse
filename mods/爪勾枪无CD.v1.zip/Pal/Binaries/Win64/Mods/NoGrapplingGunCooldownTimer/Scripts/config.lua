local palConfig = {

    palModName = "No Grappling Gun Cooldown Timer - ",
    palModVersion = "1.2",
    palGameVersion = "1.4.1",

    palRedColorWrapperFront = "\27[31m",
    palRedColorWrapperBack = "\27[0m\n",

	CoolDownTime = 0.1 --How long the cooldown timer is.  Default = 8
	
}
return palConfig
