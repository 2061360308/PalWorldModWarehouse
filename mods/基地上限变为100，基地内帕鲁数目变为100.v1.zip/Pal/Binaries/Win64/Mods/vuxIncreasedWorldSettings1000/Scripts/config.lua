local vuxConfig = {
    -- Mod info
    vuxModName = "Increased world settings",
    vuxGameVersion = "0.1.4.0",
    vuxModVersion = "1000",

    -- Logic checks
    num1 = 1000,
    num2 = 0
}
return vuxConfig