local config = {}

config.Keybinds = {}

-- Can be enabled to allow giving unique Pal specific skills to anyone like Anubis' Spinning Roundhouse on Chikipi for example.
-- Keep in mind unique skills are not meant to work on other Pals so they will perform a default move instead and their AI will break afterwards.
-- I decided to let users choose if they want to enable this or not in case you enjoy the funny glitch resulting from this.
-- true = enabled, false = disabled
config.AllowUniqueAbilitiesOnEveryone = false

-- This adjusts how far spawned Pals can go before resetting, increase if you run into issues (Default 15000.0)
-- 15000.0 = 1500 meters
config.PalReturnRadius = 15000.0

-- Keybind for opening the Spawner UI (Default is F1)
-- List of available keybinds here: https://docs.ue4ss.com/lua-api/table-definitions/key.html
config.Keybinds.OpenSpawnerUI = Key.F1

return config