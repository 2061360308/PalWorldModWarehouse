local config = require("./creative-menu-config")

local ModActor = nil

---@class UPalLogManager
local LogManager = nil

local function GetModActor()
    if ModActor == nil or not ModActor:IsValid() then
        local ActorArray = FindAllOf("BP_SpawnerToolCore_C")
        for index, value in ipairs(ActorArray) do
            if value:IsValid() then
                if not value:HasAnyFlags(EObjectFlags.RF_ClassDefaultObject) then
                    ModActor = FindFirstOf("BP_SpawnerToolCore_C")
                    return ModActor
                else
                    print("Default was included for some reason\n")
                end
            end
        end
    end
    return ModActor
end

local function Log(message, useLogManager)
    print("[Lua CreativeMenu] " .. message .. "\n")

    if useLogManager == true then
        if LogManager == nil or not LogManager:IsValid() then
            LogManager = FindFirstOf("BP_PalLogManager_C")
        end
        if LogManager ~= nil and LogManager:IsValid() then
            LogManager:AddLog(1, FText(message), {})
        end
    end
end

local function NotifyModActorNotFound()
    Log("ModActor not found, please verify you installed CreativeMenu.pak correctly.", true)
end

---@param Context APalPlayerState
---@param ChatMessage FPalChatMessage
RegisterHook("/Script/Pal.PalPlayerState:EnterChat_Receive", function (Context, ChatMessage)
    if ChatMessage:get().Message:ToString() == "/creativemenu" then
        local _ModActor = GetModActor()
        if _ModActor ~= nil and _ModActor:IsValid() then
            local Controller = Context:get():GetPlayerController()
            if Controller ~= nil and Controller:IsValid() then
                _ModActor:OnServerAcknowledgePossession(Controller)
            end
        end
    end
end)

RegisterKeyBind(Key.ESCAPE, {}, function ()
    ExecuteInGameThread(function ()
        local _ModActor = GetModActor()
        if _ModActor ~= nil and _ModActor:IsValid() then
            _ModActor:CloseSpawnerUI()
        else
            NotifyModActorNotFound()
        end    
    end)
end)

RegisterKeyBind(config.Keybinds.OpenSpawnerUI, {}, function ()
    local _ModActor = GetModActor()
    if _ModActor ~= nil and _ModActor:IsValid() then
        _ModActor:OpenSpawnerUI()
    else
        NotifyModActorNotFound()
    end
end)

RegisterKeyBind(config.Keybinds.OpenSpawnerUI, {ModifierKey.SHIFT}, function ()
    local _ModActor = GetModActor()
    if _ModActor ~= nil and _ModActor:IsValid() then
        _ModActor:OpenSpawnerUI()
    else
        NotifyModActorNotFound()
    end
end)

RegisterCustomEvent("LUA_CreativeMenuSetup", function (Context)
    Context:get().bAllowUniqueAbilitiesOnAnyone = config.AllowUniqueAbilitiesOnEveryone
    Context:get().PalReturnRadius = config.PalReturnRadius
    ModActor = Context:get()
    Log("Blueprint successfully configured!")
end)

print("[Lua CreativeMenu] Loaded successfully!\n")