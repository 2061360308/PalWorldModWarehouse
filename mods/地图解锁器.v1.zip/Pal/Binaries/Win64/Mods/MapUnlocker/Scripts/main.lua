--Open entire map
NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
  PalGameSetting.worldmapUIMaskClearSize = 20000
end)
--Open entire map