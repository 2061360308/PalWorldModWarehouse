local vuxConfig = {
    -- Mod info
    vuxModName = "Remove/Reduce Pal revive timer",
    vuxGameVersion = "0.1.4.0",
    vuxModVersion = "remove",

    -- Logic checks
    vuxCheckRestart = 0,
    vuxCheckAcknowledge = 0,

    -- Mod configs
    -- Time in minutes, 0 =  none, 1 = 1 minute etc
    vuxReviveTimer = 0
}
return vuxConfig