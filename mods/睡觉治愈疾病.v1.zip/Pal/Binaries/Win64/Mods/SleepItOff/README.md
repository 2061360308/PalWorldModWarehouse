# PalSleepItOff
Sleeping will cure a Pal of their diseases
